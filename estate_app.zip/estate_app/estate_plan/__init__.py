# custom_app/custom_app/__init__.py

# Example inclusion in __init__.py
# Import statements and other initialization code

# Ensure custom functions are loaded
from .custom_scripts import jinja_script
