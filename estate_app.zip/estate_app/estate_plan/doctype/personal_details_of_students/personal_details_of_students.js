// Copyright (c) 2024, Anna and contributors
// For license information, please see license.txt

// frappe.ui.form.on("Personal Details Of Students", {
// 	refresh(frm) {

// 	},
// });
// File: my_custom_app/custom_scripts/student_custom_button.js


