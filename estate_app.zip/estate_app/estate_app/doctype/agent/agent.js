// Copyright (c) 2024, Anna and contributors
// For license information, please see license.txt

// frappe.ui.form.on("AGENT", {
// 	refresh(frm) {

// 	},
// });
