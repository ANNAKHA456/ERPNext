# # Copyright (c) 2024, Anna and contributors
# # For license information, please see license.txt

# # import frappe
# from frappe.model.document import Document


# class AGENT(Document):
# 	pass
# Copyright (c) 2024, Anna and contributors
# For license information, please see license.txt

import frappe
from frappe.model.document import Document

class AGENT(Document):
    def after_insert(self):
        notify_user_status()

def notify_user_status():
    # Fetch all users and their status
    users = frappe.get_all("User", fields=["name", "enabled"])
    
    # Prepare the message
    user_statuses = "<br>".join([f"User: {user['name']}, Enabled: {user['enabled']}" for user in users])
    
    # Create a notification
    frappe.msgprint(
        msg=user_statuses,
        title="User Statuses",
        indicator="blue"
    )
