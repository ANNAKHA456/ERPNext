# Copyright (c) 2024, Anna and Contributors
# See license.txt

# import frappe
from frappe.tests.utils import FrappeTestCase


class TestPropertyAmenityDetails(FrappeTestCase):
	pass
